import PCPictures_gui


def tarea():
	# Aqui empieza tu tarea
	pass
#Aqui termina su tarea

app = PCPictures_gui.Application("tarea")
app.title('PCPictures CLC 2022')
app.loadProgram(tarea)
app.start()
